---
name: Question
about: Ask a question
title: "[Question] Question title"
---

# Questions

If in doubt, we highly recommend users and contributors to ask questions can be asked on the [Open Source Mechanistic Interpretability Slack](https://join.slack.com/t/opensourcemechanistic/shared_invite/zt-375zalm04-GFd5tdBU1yLKlu_T_JSqZQ). However, you should feel comfortable asking questions here as well!

The codebase is a work in progress and so if you come accross something confusing or unclear it's very plausible that this isn't well documented and should be!
