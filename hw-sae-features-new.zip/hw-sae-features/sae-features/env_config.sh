# 脚本仅支持 Linux 系统，使用 uv 虚拟环境管理工具
# 脚本运行方式为 bash env_config.sh
# 运行完成后，将在当前目录下生成 .venv 目录，包含 uv 虚拟环境和所需依赖包
# 在 notebook 中选择内核时，请选择对应目录中包含的环境

#! /bin/bash

# Install uv
curl -LsSf https://gitee.com/wangnov/uv-custom/releases/download/0.9.15/uv-installer-custom.sh | sh
source ~/.bashrc

uv venv --python 3.11
source .venv/bin/activate

cd SAEDashboard
uv pip install -e .
cd ../SAELens
uv pip install -e .
cd ..
uv pip install -r requirements.txt
